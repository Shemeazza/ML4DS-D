# Import necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

# Load the dataset
file_path = "C:/Users/Dao Duc Minh/OneDrive/Máy tính/train.csv"
df = pd.read_csv(file_path)

# Display the first few rows of the dataset
print("Dataset Preview:")
print(df.head())

# Check for missing data
missing_data = df.isnull().sum()
print("\nMissing Data:")
print(missing_data)

# Explore Data Statistics
summary_stats = df.describe()
print("\nSummary Statistics:")
print(summary_stats)

# Feature Engineering: Extracting temporal features
df['YearMonth'] = df['Year'].astype(str) + df['Month'].astype(str).str.zfill(2)

# Separate features and labels
X = df[['Year', 'Month', 'Consumption', 'YearMonth']]
y = df['Consumer_type']

# Build and train a Random Forest Classifier
model = RandomForestClassifier(random_state=42)
model.fit(X, y)

# Classify a set of consumers provided in a CSV file
consumers_to_classify_path = "C:/Users/Dao Duc Minh/OneDrive/Máy tính/train.csv"
df_consumers_to_classify = pd.read_csv(consumers_to_classify_path)

# Feature engineering for the consumers to classify
df_consumers_to_classify['YearMonth'] = df_consumers_to_classify['Year'].astype(str) + df_consumers_to_classify['Month'].astype(str).str.zfill(2)
X_to_classify = df_consumers_to_classify[['Year', 'Month', 'Consumption', 'YearMonth']]

# Make predictions for the consumers to classify
predicted_consumer_types = model.predict(X_to_classify)

# Create a DataFrame with the results
results_df = pd.DataFrame({
    'Consumer_number': df_consumers_to_classify['Consumer_number'],
    'Predicted_Consumer_Type': predicted_consumer_types
})

# Save the results to a CSV file with a specific path
results_df.to_csv(r"C:\Users\Dao Duc Minh\OneDrive\Máy tính\BIP ex\predicted_results.csv", index=False)
print("\nPredicted Results:")
print(results_df.head())
