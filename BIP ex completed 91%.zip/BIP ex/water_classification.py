import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import LabelEncoder
import numpy as np

# Load the training dataset
file_path_train = "C:/Users/Dao Duc Minh/OneDrive/Máy tính/train.csv"
df_train = pd.read_csv(file_path_train)

# Display the first few rows of the training dataset
print("Training Dataset Preview:")
print(df_train.head())

# Explore Data Statistics for the training dataset
summary_stats_train = df_train.describe()
print("\nSummary Statistics for Training Dataset:")
print(summary_stats_train)

# Check unique values in the 'Year' column
unique_years = df_train['Year'].unique()
print("\nUnique Years in Training Dataset:")
print(unique_years)

# Feature Engineering: Extracting temporal features
df_train['YearMonth'] = df_train['Year'].astype(str) + df_train['Month'].astype(str).str.zfill(2)

# Separate features and labels for the training dataset
X_train = df_train[['Year', 'Month', 'Consumption', 'Installation_zone']]
y_train = df_train['Consumer_type']

# Encode categorical features for the training dataset
label_encoder_train = LabelEncoder()
X_train.loc[:, 'Installation_zone'] = label_encoder_train.fit_transform(X_train['Installation_zone'])

# Split the training data into training and testing sets
X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

# Build and train a Random Forest Classifier
model = RandomForestClassifier(random_state=42)
model.fit(X_train_split, y_train_split)

# Evaluate the model on the testing set
y_pred_test = model.predict(X_test_split)
accuracy_test = accuracy_score(y_test_split, y_pred_test)

# Print accuracy and classification report for the testing set
print("\nModel Accuracy on Test Set:", accuracy_test)
print("\nClassification Report on Test Set:")
print(classification_report(y_test_split, y_pred_test))

# Load the competition dataset
file_path_competition = "C:/Users/Dao Duc Minh/OneDrive/Máy tính/competition.csv"
df_competition = pd.read_csv(file_path_competition)

# Handle unknown labels in the competition dataset
for col in ['Installation_zone']:
    unknown_labels = set(df_competition[col]) - set(label_encoder_train.classes_)
    if unknown_labels:
        # Add a new label for unknown values during encoding
        label_encoder_train.classes_ = np.concatenate([label_encoder_train.classes_, ['unknown_label']])
        df_competition[col] = df_competition[col].replace(unknown_labels, 'unknown_label')

# Feature engineering for the competition dataset
df_competition['YearMonth'] = df_competition['Year'].astype(str) + df_competition['Month'].astype(str).str.zfill(2)
df_competition.loc[:, 'Installation_zone'] = label_encoder_train.transform(df_competition['Installation_zone'])

# Exclude non-numeric columns from the feature set for prediction
X_competition = df_competition[['Year', 'Month', 'Consumption', 'Installation_zone']]

# Ensure that the feature set for prediction has the same columns as the training data
missing_features = set(X_train.columns) - set(X_competition.columns)
if missing_features:
    raise ValueError(f"Missing features in competition data: {missing_features}")

# Make predictions for the competition dataset
predicted_consumer_types_competition = model.predict(X_competition)

# Create a DataFrame with the results for the competition dataset
results_competition_df = pd.DataFrame({
    'Consumer_number': df_competition['Consumer_number'],
    'Consumer_type': predicted_consumer_types_competition
})

# Save the results to a CSV file for the competition dataset
results_competition_df.to_csv("C:/Users/Dao Duc Minh/OneDrive/Máy tính/BIP ex/predicted_results_competition.csv", index=False)
print("\nPredicted Results for the Competition Dataset:")
print(results_competition_df.head())
